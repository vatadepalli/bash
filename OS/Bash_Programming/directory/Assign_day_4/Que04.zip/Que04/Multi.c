#include<stdio.h>

void Multi(int a,int b){
	printf("Product of %d & %d is %d\n",a,b,a*b);
}
