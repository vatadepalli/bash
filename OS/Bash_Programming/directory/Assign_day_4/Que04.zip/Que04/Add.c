#include<stdio.h>

void Add(int a,int b){
	printf("Sum of %d & %d is %d\n",a,b,a+b);
}
