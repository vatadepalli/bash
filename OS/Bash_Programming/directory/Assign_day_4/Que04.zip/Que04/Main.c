#include<stdio.h>

int main()
{
	Add(10,20);
	Sub(10,20);
	Multi(20,3);
	Divide(30,40);
	return 0;
}
