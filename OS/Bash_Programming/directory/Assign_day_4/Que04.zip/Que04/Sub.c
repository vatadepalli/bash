#include<stdio.h>
#include<stdlib.h>

void Sub(int a,int b){
	printf("Difference of %d & %d is %d\n",a,b,abs(a-b));
}
